# سوق ديمو (واجهة مثل حراج)

هذه واجهة ديمو (Static) بدون باكند أو قاعدة بيانات.

## التشغيل (الأفضل عبر سيرفر محلي بسيط)
> مهم: لا تفتح index.html مباشرة (بعض المتصفحات تمنع fetch للـ JSON).  
استخدم سيرفر محلي.

### خيار 1: Python
```bash
cd haraj-demo
python -m http.server 8000
```
ثم افتح:
http://localhost:8000/index.html

### خيار 2: Node
```bash
npx serve .
```

## الملفات
- index.html الرئيسية
- browse.html التصفح + الفلاتر
- listing.html صفحة الإعلان
- post.html إضافة إعلان (ديمو)
- data.json بيانات وهمية
- assets/style.css
- assets/app.js
