
const state = {
  data: null,
  favorites: new Set(JSON.parse(localStorage.getItem('favorites') || '[]')),
};

function qs(sel, el=document){ return el.querySelector(sel); }
function qsa(sel, el=document){ return [...el.querySelectorAll(sel)]; }

function formatPrice(p){
  if(!p || p===0) return 'على السوم';
  return new Intl.NumberFormat('ar-SA').format(p) + ' ر.س';
}

function daysAgo(iso){
  const d = new Date(iso);
  const now = new Date();
  const diff = Math.floor((now - d)/(1000*60*60*24));
  if(diff<=0) return 'اليوم';
  if(diff===1) return 'أمس';
  return `قبل ${diff} يوم`;
}

function toast(msg){
  const t = qs('.toast');
  qs('.t', t).textContent = msg;
  t.style.display='flex';
  clearTimeout(window.__t);
  window.__t=setTimeout(()=>t.style.display='none', 2200);
}

function saveFav(){
  localStorage.setItem('favorites', JSON.stringify([...state.favorites]));
}

function toggleFavorite(id){
  if(state.favorites.has(id)){
    state.favorites.delete(id);
    toast('تمت الإزالة من المفضلة');
  }else{
    state.favorites.add(id);
    toast('تمت الإضافة للمفضلة');
  }
  saveFav();
  renderFavoriteBadges();
}

function renderFavoriteBadges(){
  qsa('[data-fav]').forEach(btn=>{
    const id = btn.getAttribute('data-fav');
    btn.textContent = state.favorites.has(id) ? '★ مفضلة' : '☆ مفضلة';
  });
}

function buildCard(item){
  const img = item.images?.[0] || '';
  const badge = item.price ? `<span class="badge green">سعر</span>` : `<span class="badge">على السوم</span>`;
  return `
  <div class="card">
    <a href="listing.html?id=${encodeURIComponent(item.id)}">
      <div class="thumb" style="background-image:url('${img}')"></div>
    </a>
    <div class="card-body">
      <a href="listing.html?id=${encodeURIComponent(item.id)}"><p class="title">${item.title}</p></a>
      <div class="meta">
        <span class="badge">${item.categoryName}</span>
        <span>${item.city} • ${item.district}</span>
        <span>👁️ ${item.views}</span>
        <span>${daysAgo(item.created)}</span>
      </div>
      <div class="price">
        ${badge}
        <span>${formatPrice(item.price)}</span>
        <button class="btn ghost" style="margin-inline-start:auto" data-fav="${item.id}">☆ مفضلة</button>
      </div>
    </div>
  </div>
  `;
}

function getParams(){
  const p = new URLSearchParams(location.search);
  const obj = {};
  for(const [k,v] of p.entries()) obj[k]=v;
  return obj;
}

async function loadData(){
  // Mobile-friendly: if opened as a file:// on phone, fetch('data.json') may be blocked.
  // We embed data in assets/data-embedded.js and fall back to fetch if needed.
  if(window.__DATA__){
    state.data = window.__DATA__;
    return;
  }
  const res = await fetch('data.json');
  state.data = await res.json();
}

function renderNav(){
  const loginBtn = qs('#loginBtn');
  const modal = qs('#loginModal');
  const closeBtn = qs('#closeModal');
  if(loginBtn && modal){
    loginBtn.addEventListener('click', ()=> modal.style.display='flex');
    closeBtn?.addEventListener('click', ()=> modal.style.display='none');
    modal.addEventListener('click', (e)=>{ if(e.target===modal) modal.style.display='none'; });
  }
}

function renderHome(){
  const catsEl = qs('#categories');
  const latestEl = qs('#latest');
  if(!catsEl || !latestEl) return;

  catsEl.innerHTML = state.data.categories.map(c=>`
    <a class="cat" href="browse.html?cat=${encodeURIComponent(c.id)}">
      <div>
        <div style="font-weight:900">${c.name}</div>
        <small>تصفح أحدث الإعلانات</small>
      </div>
      <div class="icon">${c.icon}</div>
    </a>
  `).join('');

  const latest = [...state.data.listings]
    .sort((a,b)=> new Date(b.created) - new Date(a.created))
    .slice(0, 12);

  latestEl.innerHTML = latest.map(buildCard).join('');
  qsa('[data-fav]').forEach(btn=> btn.addEventListener('click', (e)=>{ e.preventDefault(); toggleFavorite(btn.dataset.fav); }));
  renderFavoriteBadges();
}

function filterListings({q, cat, city, min, max, sort, fav}){
  let items = [...state.data.listings];

  if(cat) items = items.filter(x=>x.category===cat);
  if(city) items = items.filter(x=>x.city===city);
  if(q) {
    const s = q.trim().toLowerCase();
    items = items.filter(x => (x.title + ' ' + x.description).toLowerCase().includes(s));
  }
  if(fav==='1') items = items.filter(x=>state.favorites.has(x.id));
  if(min) items = items.filter(x=> (x.price||0) >= Number(min));
  if(max) items = items.filter(x=> (x.price||0) <= Number(max));

  switch(sort){
    case 'price_asc': items.sort((a,b)=>(a.price||0)-(b.price||0)); break;
    case 'price_desc': items.sort((a,b)=>(b.price||0)-(a.price||0)); break;
    case 'views': items.sort((a,b)=>b.views-a.views); break;
    default: items.sort((a,b)=> new Date(b.created)-new Date(a.created));
  }
  return items;
}

function renderBrowse(){
  const listEl = qs('#results');
  if(!listEl) return;

  const p = getParams();
  // Prefill controls
  const qIn = qs('#q'); const catSel = qs('#cat'); const citySel = qs('#city');
  const minIn = qs('#min'); const maxIn = qs('#max'); const sortSel = qs('#sort'); const favChk = qs('#fav');

  if(catSel){
    catSel.innerHTML = `<option value="">كل الأقسام</option>` + state.data.categories.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    catSel.value = p.cat || '';
  }
  if(citySel){
    citySel.innerHTML = `<option value="">كل المدن</option>` + state.data.cities.map(c=>`<option value="${c}">${c}</option>`).join('');
    citySel.value = p.city || '';
  }
  if(qIn) qIn.value = p.q || '';
  if(minIn) minIn.value = p.min || '';
  if(maxIn) maxIn.value = p.max || '';
  if(sortSel) sortSel.value = p.sort || 'new';
  if(favChk) favChk.checked = (p.fav === '1');

  const apply = ()=>{
    const query = {
      q: qIn?.value || '',
      cat: catSel?.value || '',
      city: citySel?.value || '',
      min: minIn?.value || '',
      max: maxIn?.value || '',
      sort: sortSel?.value || 'new',
      fav: favChk?.checked ? '1' : '0',
    };
    const items = filterListings(query);
    qs('#count').textContent = `${items.length} إعلان`;

    listEl.innerHTML = items.map(buildCard).join('');
    qsa('[data-fav]').forEach(btn=> btn.addEventListener('click', (e)=>{ e.preventDefault(); toggleFavorite(btn.dataset.fav); }));
    renderFavoriteBadges();

    // update url
    const sp = new URLSearchParams();
    Object.entries(query).forEach(([k,v])=>{ if(v && v!=='0' && !(k==='sort' && v==='new')) sp.set(k,v); });
    history.replaceState(null,'', 'browse.html?' + sp.toString());
  };

  qsa('input,select', qs('#filters')).forEach(el=> el.addEventListener('input', apply));
  qs('#reset')?.addEventListener('click', ()=>{
    qIn.value=''; catSel.value=''; citySel.value=''; minIn.value=''; maxIn.value=''; sortSel.value='new'; favChk.checked=false;
    apply();
  });

  apply();
}

function renderListing(){
  const root = qs('#listing');
  if(!root) return;
  const {id} = getParams();
  const item = state.data.listings.find(x=>x.id===id) || state.data.listings[0];

  qs('#crumbCat').textContent = item.categoryName;
  qs('#crumbCat').href = `browse.html?cat=${encodeURIComponent(item.category)}`;

  qs('#title').textContent = item.title;
  qs('#price').textContent = formatPrice(item.price);
  qs('#city').textContent = `${item.city} • ${item.district}`;
  qs('#created').textContent = daysAgo(item.created);
  qs('#views').textContent = item.views;

  // gallery
  qs('#imgBig').style.backgroundImage = `url('${item.images[0]}')`;
  qs('#imgS1').style.backgroundImage = `url('${item.images[1]}')`;
  qs('#imgS2').style.backgroundImage = `url('${item.images[2]}')`;

  const setBig = (url)=> qs('#imgBig').style.backgroundImage = `url('${url}')`;
  qs('#imgBig').addEventListener('click', ()=> window.open(item.images[0], '_blank'));
  qs('#imgS1').addEventListener('click', ()=> setBig(item.images[1]));
  qs('#imgS2').addEventListener('click', ()=> setBig(item.images[2]));

  qs('#desc').textContent = item.description;

  qs('#sellerName').textContent = item.seller.name;
  qs('#sellerSince').textContent = `عضو منذ ${item.seller.memberSince}`;
  qs('#sellerVer').innerHTML = item.seller.verified ? `<span class="badge green">موثّق</span>` : `<span class="badge">غير موثّق</span>`;

  const favBtn = qs('#favBtn');
  favBtn.setAttribute('data-fav', item.id);
  favBtn.addEventListener('click', ()=> toggleFavorite(item.id));
  renderFavoriteBadges();

  qs('#callBtn').addEventListener('click', ()=> toast('ديمو: زر الاتصال'));
  qs('#waBtn').addEventListener('click', ()=> toast('ديمو: زر واتساب'));
  qs('#repBtn').addEventListener('click', ()=> toast('تم إرسال البلاغ (ديمو)'));

  // similar
  const sim = state.data.listings
    .filter(x=>x.category===item.category && x.id!==item.id)
    .slice(0, 6);
  qs('#similar').innerHTML = sim.map(buildCard).join('');
  qsa('[data-fav]').forEach(btn=> btn.addEventListener('click', (e)=>{ e.preventDefault(); toggleFavorite(btn.dataset.fav); }));
  renderFavoriteBadges();
}

function renderPost(){
  const form = qs('#postForm');
  if(!form) return;

  // build category options
  const cat = qs('#pCat');
  cat.innerHTML = state.data.categories.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');

  const city = qs('#pCity');
  city.innerHTML = state.data.cities.map(c=>`<option value="${c}">${c}</option>`).join('');

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    toast('ديمو: تم حفظ الإعلان (بدون قاعدة بيانات)');
    form.reset();
  });
}

async function init(){
  await loadData();
  renderNav();

  // global search
  const topSearch = qs('#topSearch');
  const topSearchBtn = qs('#topSearchBtn');
  if(topSearch){
    const go = ()=>{
      const q = topSearch.value.trim();
      location.href = 'browse.html' + (q ? `?q=${encodeURIComponent(q)}` : '');
    };
    topSearch.addEventListener('keydown', (e)=>{ if(e.key==='Enter') go(); });
    topSearchBtn?.addEventListener('click', go);
  }

  renderHome();
  renderBrowse();
  renderListing();
  renderPost();
}

document.addEventListener('DOMContentLoaded', init);
